#include <iostream>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include<algorithm>
#include <chrono>
#include <functional>
#include <math.h>
#include <algorithm>
#include <pthread.h>
#include <unistd.h>
#include <windows.h>

#include <cstdio>
#include <cstdint>

#include <cstring>
#include <utility>
#include <cinttypes>
using namespace std;

#define D cout<<"DEBUG"<<endl;

#include<stdio.h>
#include<string.h>

#include<stdlib.h>

int primes[10][100110];


int get_seeded_random(int seed){
	time_t zeit=seed;
srand(zeit);
long long r=rand();
srand(time(NULL));
r=r*rand()%100;
int tempmulti=seed*5;
for(int i=0;i<tempmulti;i++){
	r=r*r;
	r=r%10000;
	r=r+rand()%8;
	r=r%10000;
	r=r+rand()%7;
	r=r%10000;
	r=r+rand();
	r=r%10000;
}
r=sqrt(r*r);
return r;
}






void* a(void* test){
int prime;

int primescount=0;
int min=*(int*)test;
for (int i=min;i<min+10000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primescount++;
			
			pthread_t id=pthread_self();
			
			
					primes[id][primescount]=i;
			
		
		}
		
		
	}
	prime=0;
	
		}
		 
	


	

pthread_exit(NULL);
}

void* b(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=10000;i<20000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"2";
pthread_exit(NULL);
}
void* c(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=20000;i<30000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"3";
pthread_exit(NULL);
}


void* d(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=30000;i<40000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"4";
pthread_exit(NULL);
}

void* e(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=40000;i<50000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"5";
pthread_exit(NULL);
}


void* f(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=60000;i<70000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"6";
pthread_exit(NULL);
}


void* g(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=80000;i<90000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"7";
pthread_exit(NULL);
}


void* h(void* test){
	
	
	int prime;
vector<int> primes;
for (int i=90000;i<100000;i++){
	for (int b=i-1;b>1;b--){
		int c=i%b;
		if(c==0){prime=1;}
		if(prime==0 && b==2){
			primes.push_back(i);
		}
		
		
	}
	prime=0;
		}
	
cout<<"8";
pthread_exit(NULL);
}















int main() {


	pthread_t t1;
	pthread_t t2;
	pthread_t t3;
	pthread_t t4;
	pthread_t t5;
	pthread_t t6;
	pthread_t t7;
	pthread_t t8;
 
    int i=0;
    int t=1000;

	cout<<":"<<endl;
  if(  pthread_create(&t1, NULL, &a, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<".";
  
  }
  
  
  
 
   if(  pthread_create(&t2, NULL, &b, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"2";
  }
  
   if(  pthread_create(&t3, NULL, &c, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"3";
  }
  
   if(  pthread_create(&t4, NULL, &d, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"4";
  }
  
   if(  pthread_create(&t5, NULL, &e, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"5";
  }
  
  if(  pthread_create(&t6, NULL, &f, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"6";
  }
  
  if(  pthread_create(&t7, NULL, &g, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"7";
  }
  
  if(  pthread_create(&t8, NULL, &h, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"8";
  }

    cout<<endl;
	 
i++;
 



   
   int test;
     

pthread_join(t1,(void **)&test);
pthread_join(t2,(void **)&test);
pthread_join(t3,(void **)&test);
pthread_join(t4,(void **)&test);
pthread_join(t5,(void **)&test);
pthread_join(t6,(void **)&test);
pthread_join(t7,(void **)&test);
pthread_join(t8,(void **)&test);   

   
   /*
for (int spalte=0;spalte<11;spalte++){
	for (int zeile=0;zeile<10012;zeile++){
		cout<<primes[spalte][zeile]<<",";
	}
	cout<<endl;
}

*/





    return 0;
}
