using namespace std;
#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>


#include <sstream>
#include <string>
class Net;
class Weight;
class Neuron;


class Weight{
	public:
	long double weight;
	
	
};

class Neuron{
	
	public:
		
		long double WerteWeiterGeben(long double eingabeWert);
		vector<Weight> weights;
		int anzahlNextNeurons;
		
		void FirstFillWeights();
			
		
		
};

class Net{
	public:
	int anzahlNeuronen;
	int anzahlWeights;
	int anzahlLayers;
	vector<long double> eingangswerte;
	vector<vector<Neuron> > neuralesNetz;
	void ShowWeights();
	void Save();
	void LoadWeights();
	
};


