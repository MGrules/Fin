#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>

#include <sstream>
#include <string>
using namespace std;
long double betrag(double wert);
int main(){
	while (true){
	
long double a;	
long double b;
long double c;
cin>>a;	
cin>>b;	
	long double d;
	c=a*b;
	d=1+betrag(c);
cout<<setprecision(20)<<"a * b = "<<c<<endl;
c=c/d;
cout<<"1 + abs(c) = "<<d<<endl;
cout<<"sigmoid(d) = "<<"c/d = "<<c<<endl<<endl;	
	
	
}
	
	
}

long double betrag(double wert){
	
	if(wert<0){
		wert*=-1;
	}
	return wert;
}
