#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>

#include <sstream>
#include <string>
#define D cout<<endl<<"DEBUG"<<endl;
long double betrag(long double wert);
class Neuron;
class Net;
class Weight;



//void ErstelleNetz(Net myNet,vector<int> strukturVektor;);
using namespace std;


ifstream getInput;
ofstream ausgabe;
ifstream eingabe;



long double betrag(long double wert){
	if(wert<0){
		wert*=-1;
		return wert;
	}
	return wert;
}


class Weight{
	public:
	long double weight;
	
	
};

class Neuron{
	
	public:
		
		void WerteWeiterGeben(int i);
		vector<Weight> weights;
		int anzahlNextNeurons;
		vector<long double> tempStorage;
		long double storedValue;
		void FirstFillWeights();
		void calculateSum();	
		
		
};


class Net{
	public:
	int anzahlNeuronen;
	int anzahlWeights;
	int anzahlLayers;
	vector<long double> eingangswerte;
	vector<vector<Neuron> > neuralesNetz;
	void ShowWeights();
	void Save();
	void LoadWeights();
	void GetWerteFromFile();
	void PutWerteToNN(vector<int>strukturVektor);
	void FeedForward(vector<int> strukturVektor);
	
};


Net myNet;

void Net::PutWerteToNN(vector<int>strukturVektor){
	
	for(int i=0;i<strukturVektor[0];i++){
		myNet.neuralesNetz[0][i].storedValue=myNet.eingangswerte[i];
	}
	
}


void Net::FeedForward(vector<int> strukturVektor){
	
	for(int i=0;i<anzahlLayers;i++){
		for(int a=0;a<strukturVektor[i];a++){
		
				neuralesNetz[i][a].WerteWeiterGeben(i);
	
		}
	}
	

	
	
}

void Net::GetWerteFromFile(){
	
	getInput.open("1.nn");
	
	
	if(!getInput.is_open()){
		cout<<"CANT LOAD '.nn' FILE"<<endl;
	}else{
	
	
	vector<vector<string> > data;
	while (getInput)
  {
  	
    string s;
    if (!getline( getInput, s )) break;

    istringstream ss( s );
    vector <string> record;

    while (ss)
    {
      
      string s;
      if (!getline( ss, s, ';' )) break;
      record.push_back( s );
      
      string::size_type sz;
      double temp = std::stod (s,&sz);
  
      
      myNet.eingangswerte.push_back(temp);
      
      
    }

    data.push_back( record );
  }
  if (!getInput.eof())
  {
    cerr << "File Ended on .nn file";
    
  }
	
		
		
		
		
		
		
	}
	
	
	
	
	
	
}



void Net::LoadWeights(){
	int count=0;
	eingabe.open("1.weights");
	
	cout<<endl;
	vector<vector<string> > data;
	while (eingabe)
  {
    string s;
    if (!getline( eingabe, s )) break;

    istringstream ss( s );
    vector <string> record;

    while (ss)
    {
      
      string s;
      if (!getline( ss, s, ';' )) break;
      record.push_back( s );
      
      count++;
    }

    data.push_back( record );
  }
  if (!eingabe.eof())
  {
    cerr << "File Ended on .weights";
    
  }


	
	
	
	
	
}




void Neuron::FirstFillWeights(){
	
for(int i=0;i<anzahlNextNeurons;i++)	{
	
	weights.push_back(Weight{1.0/rand()});
	
}
	
}



void Net::ShowWeights(){
	
	for(int i=0;i<anzahlLayers;i++){
		for(int a=0;a<neuralesNetz[i].size();a++){
			for(int b=0;b<neuralesNetz[i][a].anzahlNextNeurons;b++){
				cout<<neuralesNetz[i][a].weights[b].weight;
			}
		}
	}
	
	
}

void Net::Save(){
	
	for(int i=0;i<anzahlLayers;i++){
		
		for(int a=0;a<neuralesNetz[i].size();a++){
			
			for(int b=0;b<neuralesNetz[i][a].anzahlNextNeurons;b++){
					
					
					
					long double tempWeights=neuralesNetz[i][a].weights[b].weight;
					
					long double tempWeightsLong=1000.0/tempWeights;
					
					
					tempWeightsLong/=1000.0;
					
						
					ausgabe<<fixed<<setprecision(1)<<tempWeightsLong;
					
				ausgabe<<";";
			
				
				cout<<i<<","<<a<<","<<b<<endl;
				
			}
		}
		
		cout<<"layer"<<i<<" successfull"<<endl;
	}
}



void Neuron::WerteWeiterGeben(int a){
	
	for(int i=0;i<anzahlNextNeurons;i++){
		
		myNet.neuralesNetz[a+1][i].tempStorage.push_back(storedValue);
		
	}
	

	
	
	
	
	
}




void Neuron::calculateSum(){
	for(int i=0;i<tempStorage.size();i++){
	storedValue+=tempStorage[i];
}
cout<<tempStorage.size()<<endl<<endl<<endl;
storedValue=storedValue/(1+betrag(storedValue));


}





void ErstelleNetz(vector<int> strukturVektor){
	
	srand(time(NULL));
myNet.anzahlLayers=strukturVektor.size();



cout<<"checkpoint 1 'ErstelleNetz'"<<endl;



for(int i=0;i<myNet.anzahlLayers;i++){
	myNet.anzahlNeuronen+=strukturVektor[i];

}


cout<<"checkpoint 2 'ErstelleNetz'"<<endl;


for(int i=0;i<myNet.anzahlLayers;i++){
vector<Neuron> layer;
for(int a=0;a<strukturVektor[i];a++)	{
	layer.push_back(Neuron());
	
}



myNet.neuralesNetz.push_back(layer);
}

cout<<"checkpoint 3 'ErstelleNetz'"<<endl;





for(int i=0;i<myNet.anzahlLayers;i++){
	cout<<"for Schleife 1 "<<i<<endl;
	
	for(int a=0;a<strukturVektor[i];a++){
		cout<<"for Schleife 2 "<<a<<endl;
	
		if(i<strukturVektor.size()-1){
	cout<<"if i<strukturVektor "<<endl;
	myNet.neuralesNetz[i][a].anzahlNextNeurons=strukturVektor[i+1];
	
}

	
	
}

}




for(int i=0;i<myNet.anzahlLayers;i++){
	for(int a=0;a<strukturVektor[i];a++){
		cout<<"anzahlNextNeurons: "<<i<<" "<<a<<" :"<<myNet.neuralesNetz[i][a].anzahlNextNeurons<<endl;
		myNet.neuralesNetz[i][a].FirstFillWeights();
		
	}


	
}



cout<<"checkpoint 1 'ErstelleNetz'"<<endl;

	
	
	
}

void writetofile(){

for(int i=0;i<myNet.anzahlLayers;i++){
	
	for(int a=0;a<myNet.neuralesNetz[i].size();a++){
		//ausgabe<<setprecision(100)<<myNet.neuralesNetz[i][a].eingangsWeight<<",";
	}
	
}


	
}



int main(int argc, char* argv[]){


	
/*	long temp=strtol(argv[1],NULL,10);
	temp=1;
	ausgabe.open(to_string(temp)+".nn");
*/
ausgabe.open("1.weights");
	
	
	if(ausgabe.is_open()){
		cout<<"Debug"<<endl;
	}
	if(!eingabe.is_open()){
		cout<<endl<<"CRITICAL ERROR:"<<endl<<"ERROR LOADING INPUT FILE"<<endl;
	}else cout<<endl<<"SUCCESS:"<<endl<<"LOADED INPUT FILE"<<endl;
	vector<int> strukturVektor;
	
	
	strukturVektor.push_back(6);
	strukturVektor.push_back(1);
	strukturVektor.push_back(4);
	
	ErstelleNetz(strukturVektor);
	

		
	

	
	
	myNet.Save();
	
	ausgabe.close();
	
	myNet.LoadWeights();
	
	
	
	myNet.GetWerteFromFile();
	myNet.PutWerteToNN(strukturVektor);
myNet.FeedForward(strukturVektor);

for(int i=0;i<strukturVektor[1];i++){
myNet.neuralesNetz[1][i].calculateSum();
}


for(int i=0;i<strukturVektor[0];i++){
	cout<<endl<<myNet.neuralesNetz[0][i].storedValue<<"-----";
}
for(int i=0;i<strukturVektor[1];i++){

		cout<<myNet.neuralesNetz[1][i].storedValue<<endl;

	}

}





