#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>
#include<algorithm>
#include <sstream>
#include <unistd.h>
#include <string>
#include <pthread.h>






using namespace std;



void create(){
	
	srand(time(NULL));
	for(int i=0;i<100 ;i++){	
	ofstream file,save;
	string str1="./data/";
	str1+=to_string(i);
	string str2=str1;
	str2+=".saveoption";
	str1+=".weights";
	file.open(str1);
	save.open(str2);
	
	for(int a=0;a<128;a++){
		int temp=rand()%2000-1000;
		file<<temp<<";";
		save<<temp<<";";
		
	
	}
	

	
	
	file.close();
	}
}







int main(){
	pthread_t threads[100];
	
	
	create();
	
	
	
	

	
	
}
