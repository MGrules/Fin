#include <iostream>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include<algorithm>
#include <chrono>
#include <functional>
#include <math.h>
#include <algorithm>
#include <pthread.h>
#include <unistd.h>
#include <windows.h>

#include <cstdio>
#include <cstdint>

#include <cstring>
#include <utility>
#include <cinttypes>
using namespace std;

#define D cout<<"DEBUG"<<endl;

#include<stdio.h>
#include<string.h>
#define genomlen 1024
#include<stdlib.h>

ofstream file;
ofstream Genomes[400];
void instantiate_rand();
byte GenMaterial[400][genomlen];
int randomlist[1024];

int get_seeded_random(int seed){
	time_t zeit=seed;
srand(zeit);
long long r=rand();
srand(time(NULL));
r=r*rand()%100;
int tempmulti=seed*5;
for(int i=0;i<tempmulti;i++){
	r=r*r;
	r=r%10000;
	r=r+rand()%8;
	r=r%10000;
	r=r+rand()%7;
	r=r%10000;
	r=r+rand();
	r=r%10000;
	r+=randomlist[(seed+rand())%800];
}
r=sqrt(r*r);
r=r%5;
if(r==4){
	r=rand()%5;
}
switch (r){
	case(0):return 76;break;
	case(1):return 82;break;
	case(2):return 85;break;
	case(3):return 68;break;
	case(4):return 87;break;
}




}



void instantiate_rand(){
	for (int i=0;i<800;i++){
		randomlist[i]=rand();
	
	}
}


void* a(void* test){



for(int i=0;i<60;i++){
	for(int a=0;a<genomlen;a++){
	int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}

	
	
cout<<"1f";	
pthread_exit(NULL);
}

void* b(void* test){
	

for(int i=60;i<130;i++){
	for(int a=0;a<genomlen;a++){
	int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}

cout<<"2f";
pthread_exit(NULL);
}
void* c(void* test){
	
for(int i=130;i<190;i++){
	for(int a=0;a<genomlen;a++){
	int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}

	
cout<<"3f";
pthread_exit(NULL);
}
void* d(void* test){
	
	for(int i=190;i<250;i++){
	for(int a=0;a<genomlen;a++){
		int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}



cout<<"4f";
pthread_exit(NULL);
}
void* e(void* test){


for(int i=250;i<300;i++){
	for(int a=0;a<genomlen;a++){
		int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}



cout<<"5f";
pthread_exit(NULL);
}

void* f(void* test){

for(int i=300;i<350;i++){
	for(int a=0;a<genomlen;a++){
		int	p=*(int*)test *10;
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}

	
cout<<"6f";
pthread_exit(NULL);
}

void* g(void* test){
	
	for(int i=350;i<400;i++){
	for(int a=0;a<genomlen;a++){
		int	p=*(int*)test *10;
		
		GenMaterial[i][a]=get_seeded_random(*(int* )test+a+i+rand()%64);
	}
}
	
cout<<"7f";
pthread_exit(NULL);
}














void* h(void* test){
int i=*(int*)test;


Genomes[i].open(".//filestream//"+to_string(*(int*)test)+".genome", ios::binary);

for(int a=0;a<genomlen;a++){
	Genomes[i]<<GenMaterial[i][a];
	Genomes[i].flush();
}

Genomes[i].close();

pthread_exit(NULL);
}






void* j(void* test){

int i=*(int*)test;
Genomes[i].open(".//filestream//"+to_string(*(int*)test)+".genome", ios::binary);

for(int a=0;a<genomlen;a++){
	Genomes[i]<<GenMaterial[i][a];
}

Genomes[i].close();




pthread_exit(NULL);
}




void* k(void* test){


int i=*(int*)test;
Genomes[i].open(".//filestream//"+to_string(*(int*)test)+".genome", ios::binary);

for(int a=0;a<genomlen;a++){
	Genomes[i]<<GenMaterial[i][a];
}

Genomes[i].close();


	

pthread_exit(NULL);
}




void* l(void* test){
int i=*(int*)test;
Genomes[i].open(".//filestream//"+to_string(*(int*)test)+".genome", ios::binary);

for(int a=0;a<genomlen;a++){
	Genomes[i]<<GenMaterial[i][a];
}

Genomes[i].close();



pthread_exit(NULL);
}





int main() {

instantiate_rand();

file.open("test.txt");

    pthread_t t1;
    pthread_t t2;
    pthread_t t3;
    pthread_t t4;
    pthread_t t5;
    pthread_t t6;
    pthread_t t7;
    pthread_t t8;
    
    
    
    pthread_t t11[800];
    
    int i=0;
    int t=1000;

	
  if(  pthread_create(&t1, NULL, &a, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"1";
  }
  i++;
  
 
  
   if(  pthread_create(&t2, NULL, &b, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"2";
  }
  i++;
   if(  pthread_create(&t3, NULL, &c, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"3";
  }
  i++;
   if(  pthread_create(&t4, NULL, &d, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"4";
  }
  i++;
   if(  pthread_create(&t5, NULL, &e, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"5";
  }
  i++;
  if(  pthread_create(&t6, NULL, &f, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"6";
  }
  i++;
  if(  pthread_create(&t7, NULL, &g, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{cout<<"7";
  }
  i++;
 


  
   
  
  
  
  
 int test;
pthread_join(t1,(void **)&test);
pthread_join(t2,(void **)&test);
pthread_join(t3,(void **)&test);
pthread_join(t4,(void **)&test);
pthread_join(t5,(void **)&test);
pthread_join(t6,(void **)&test);
pthread_join(t7,(void **)&test);
pthread_join(t8,(void **)&test);
  

 
  cout<<endl;
    
    
    
    

    
    
    
   
    
	  i=0;
for (;i<400;++i){

 if(  pthread_create(&t11[i], NULL, &h, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{//cout<<".";
  }	
  
  
 usleep(1000);
  
i=i+1;
 if(  pthread_create(&t11[i], NULL, &j, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{
  //cout<<".";
  }
 // system("pause");
 
 
  usleep(1000);
 i=i+1;
  if(  pthread_create(&t11[i], NULL, &k, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{
  //cout<<".";
  }
  
  
 usleep(1000);
i=i+1;
  if(  pthread_create(&t11[i], NULL, &l, (void *)&i)!=0){
  	cout<<"!ERROR!";
  }else{
  //cout<<".";
  }
   
   usleep(1000);
}
   
   






for(int i=0;i<400;i++){
	pthread_join(t11[i],(void **)&test);
}
ofstream retu;
retu.open("return.werte");


    return 0;
}
