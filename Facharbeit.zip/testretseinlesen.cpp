#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>
#include<algorithm>
#include <sstream>
#include <unistd.h>
#include <string>
using namespace std;
vector<int> allRets;
vector<int>bestpos;
int findeHighestPos(vector<int>Rets){
	
int currentHigh,currentHighpos;
currentHigh=Rets[0];
currentHighpos=0;
for(int i=0;i<Rets.size();i++){
	if(Rets[i]>currentHigh){
		currentHigh=Rets[i];
		currentHighpos=i;
	}
}

return currentHighpos;

}




void showoff(){
	
	for (int i=0;i<allRets.size();i++){
		cout<<allRets[i]<<" "<<i<<endl;
	}
	
	
}


int main(){
	int count=0;
	
	
	while(true){
	ifstream file;
		string st1="./data/";
			st1+=to_string(count);
			st1+=".return";
			
			
		
		
		if(!ifstream(st1)){
			
			break;
		}
	
	

	file.open(st1);
	
	
	int temp;
	file>>temp;
	if(temp>=160){
		cout<<"wrong";
		cout<<"may be false";
	}
	file>>temp;
	allRets.push_back(temp);
	
	
	//cout<<temp<<endl;
	
	
	
	
	
 	
	
	
	
	

	
	file.close();
	count++;

}




for(int i=0;i<4;i++){
	
	
	
	
	int temp=findeHighestPos(allRets);
int	result=allRets[temp];
	bestpos.push_back(temp);
	/*
	result=max_element(allRets.begin(),allRets.end());
	//LOG<<allRets[distance(allRets.begin(),result)]<<" at "<<distance(allRets.begin(),result)<<endl;
	
//	cout<<allRets[distance(allRets.begin(),result)]<<" at "<<distance(allRets.begin(),result)<<endl;
	LOG<<allRets[distance(allRets.begin(),result)]<<" at "<<distance(allRets.begin(),result)<<endl;
	bestpos.push_back(distance(allRets.begin(),result));
	
	*/

	if(i==0){
		
		
	
		
	}
	vector<int>::iterator nth = allRets.begin() + temp;
//	allRets.erase(nth);
}



cout<<endl<<endl;
showoff();

}


