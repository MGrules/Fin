
#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>
#include<algorithm>
#include <sstream>
#include <unistd.h>
#include <string>
#include <chrono>

using namespace std;

using  ns = chrono::nanoseconds;
using get_time = chrono::steady_clock ;



int main(){



ofstream LOG,retsLOG;
string  str1="./data/LOG.LOG";	

system("del .\\data\\LOG.LOG");
system("del .\\data\\execlRets.LOG");
system("del .\\data\\retsLOG.LOG");	
retsLOG.open("./data/retsLOG.LOG");

system("InstantiateWeights.exe");
LOG.open(str1,fstream::app);
for(int i=0;i<1000;i++){


auto begin=get_time::now();



LOG<<"ITERATION "<<i<<" STARTING"<<endl;

retsLOG<<endl<<"ITERATION "<<i<<endl;


	
string str="runPacman.exe";
system(str.c_str());
	
	
	
sleep(10);
string str1="Genchanger.exe "+to_string(i);
			
		

system(str1.c_str());
	
	
	auto end=get_time::now();
	auto diff=end-begin;




retsLOG<<"ITERATION "<<i<<" DONE WITHIN "<<chrono::duration_cast<ns>(diff).count()<<" ns"<<endl;


	
}

retsLOG.close();
LOG.close();











	
}
