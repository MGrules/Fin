#include<fstream>	
#include<iostream>
#include<vector>
#include<math.h>
#include<iomanip>
#include <time.h>
#include <ctime>
#include <random>
#include <cstdlib>
#include <cstring>
#include<algorithm>
#include <sstream>
#include <unistd.h>
#include <string>
#include <pthread.h>





using namespace std;
int numOfThreads=100;
pthread_t start[100];

void* startfile(void* param){
	
int x = *((int*)(param));
	
string str1="main.exe ";
	str1+=to_string(x);
	system(str1.c_str());
	
}






/*
void* executeOrderb(void* dump){
	for(int i=10;i<20;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderc(void* dump){
	for(int i=20;i<30;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderd(void* dump){
	for(int i=30;i<40;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrdere(void* dump){
	for(int i=40;i<50;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderf(void* dump){
	for(int i=50;i<60;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderg(void* dump){
	for(int i=60;i<70;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderh(void* dump){
	for(int i=70;i<80;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderi(void* dump){
	for(int i=80;i<90;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
void* executeOrderj(void* dump){
	for(int i=90;i<100;i++){
		pthread_create(&start[i],NULL, &startfile,(void *)&i);
	}
}
*/










int main(){

	pthread_t threads[100];
ofstream LOG;
string  str1="./data/LOG.LOG";	
LOG.open(str1, fstream::app);

	
	for(int i=0;i<100;i++){
		LOG<<i<<"...";
	//	startfile(i);
	pthread_create(&threads[i],NULL, &startfile, (void *)&i);
	
		LOG.flush();
		
		
			sleep(1);
		
		if(i%15==0 && i>0){
			sleep(5);
		}
	
	
	}

	
	
	for(int i=0;i<100;i++){
		void* dump=0;
            pthread_join(threads[i], &dump);
	}
	LOG<<endl;
	LOG.close();
/*	pthread_t threads[numOfThreads];
	
	
		
		int temp=0;
		int dump;
		pthread_create(&threads[0],NULL, &executeOrdera, (void *)&temp);
		sleep(sle);
		
		/*
		pthread_create(&threads[1],NULL, &executeOrderb, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[2],NULL, &executeOrderc, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[3],NULL, &executeOrderd, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[4],NULL, &executeOrdere, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[5],NULL, &executeOrderf, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[6],NULL, &executeOrderg, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[7],NULL, &executeOrderh, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[8],NULL, &executeOrderi, (void *)&temp);
		sleep(sle);
		pthread_create(&threads[9],NULL, &executeOrderj, (void *)&temp);
		
		
		
		for(int i=0;i<10;i++){
		pthread_join(threads[i],(void **)&dump);
		}
	
		
	
	
	for(int i=0;i<100;i++){
		pthread_join(start[i],(void **)&dump);
	}
	
	
	
	*/
	
	
	return 0;
}
